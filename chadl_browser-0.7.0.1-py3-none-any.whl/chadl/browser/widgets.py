#!/usr/bin/env python

r'''Chatbot browser interface.

    Author: Helio Perroni Filho
'''


from asyncio import ensure_future
from urllib.parse import urljoin

from js import console, document
from pyodide.ffi import create_proxy
from pyodide.http import open_url

from chadl.commons.parsing import parse
from chadl.browser import Chatbot


def add_handler_by_id(element_id, event, listener):
    r'''Add an event listener to a DOM element, selected by its ID.
    '''
    element = document.getElementById(element_id)
    element.addEventListener(event, create_proxy(listener))


def create_sync(f):
    r'''Create a synchronous version of an asynchronous callable.
    '''
    def f_sync(*args, **kwargs):
        return ensure_future(f(*args, **kwargs))

    return f_sync


class URLLoader:
    r'''Class for loading files over the web from hyperlinks.
    '''
    def __init__(self, url):
        r'''Create a new loader for the given destination.
        '''
        self.url = url

    def __call__(self, name=None):
        r'''Load the contents of a given file.

            If name is `None`, open the initial URL.

            Otherwise, interpret `name` as a local path relative to the initial URL.
        '''
        if name is None:
            return open_url(self.url)

        return open_url(urljoin(self.url, name))


class Console:
    def __init__(self):
        r'''Create a new chatbot wrapper.
        '''
        self.chatbot = None
        ensure_future(self.__run())

    async def __run(self):
        r'''Start the chatbot.
        '''
        try:
            add_handler_by_id('user-input', 'keypress', create_sync(self.handle_user_input_keypress))

            self.chatbot = Chatbot(parse('http://localhost:8000/alice.xml', loader=URLLoader))

            async for line in self.chatbot.start():
                self.print_chatbot(line)

        except Exception as e:
            console.error(str(e))

    async def handle_user_input_keypress(self, e):
        r'''Callback for the Ctrl+Enter key in the user input text box.
        '''
        try:
            if not (e.ctrlKey and e.key == 'Enter'):
                return

            user_input = document.getElementById('user-input')
            self.print_user(user_input.value)

            async for line in self.chatbot.exchange(user_input.value):
                self.print_chatbot(line)

            user_input.value = ''

        except Exception as e:
            console.error(str(e))

    def print_chatbot(self, line):
        r'''Print a chatbot utterance to the log text box.
        '''
        self.print_utterance('<b><font color="#ff0000">Chatbot:</font></b><br>' + line)

    def print_user(self, line):
        r'''Print a user utterance to the log text box.
        '''
        self.print_utterance('<b><font color="#0000ff">You:</font></b><br>' + line)

    def print_utterance(self, line):
        r'''Print an utterance to the log text box.
        '''
        chatbot_output = document.getElementById('chatbot-output')
        chatbot_output.innerHTML += line  + '<br><br>'
        chatbot_output.scrollTop = chatbot_output.scrollHeight
