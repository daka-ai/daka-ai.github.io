#!/usr/bin/env python

r'''Chatbot backend for use in client-side browser applications.

    Author: Helio Perroni Filho
'''


import asyncio
import json
from urllib.parse import urljoin

from js import document
from pyodide.http import pyfetch

from chadl import commons
from chadl.commons.model import ChattingError

# Headers for sending POST requests to an external server in JSON format.
JSON_HEADERS = {
    'Content-type': 'application/json',
    'Accept': 'text/plain'
}


class Scheduler:
    r'''Object used to schedule a call for later execution.
    '''
    def __init__(self, duration, once, callback):
        r'''Create a new scheduler object.
        '''
        self.task = None

        async def run():
            while True:
                try:
                    await asyncio.sleep(duration)
                except asyncio.CancelledError:
                    return

                await callback()
                if once:
                    return

        loop = asyncio.get_event_loop()
        self.task = loop.create_task(run())

    def cancel(self):
        r'''Stop the timeout counter.
        '''
        if self.task is not None:
            self.task.cancel()


class Dispatcher(commons.Dispatcher):
    r'''Interface for communicating with the chatbot's environment.
    '''
    def __init__(self, chatbot):
        r'''Create a new dispatcher object.
        '''
        super().__init__(chatbot)
        self.__chatbot = chatbot
        self.__event_polling = commons.SchedulerOff()

    def __parameters(self):
        r'''Return the parameter dictionary from the running chatbot.
        '''
        return self.__chatbot.context.parameters

    async def __poll(self):
        r'''Poll the external service server for triggered events.
        '''
        message = await self.request('poll-events')
        if not message:
            return None

        for line in self.__chatbot.handle(message):
            self.write(line)

    def start(self):
        r'''Start the interface to the external system.
        '''
        if self.__parameters().get('polling', 'false') != 'true':
            return

        period = float(self.__parameters().get('polling-period', '1.0'))
        self.__event_polling = self.schedule(period, False, self.__poll)

    def stop(self):
        r'''Stop the interface to the external system.
        '''
        self.__event_polling.cancel()

    async def request(self, name, data=None):
        r'''Send a POST request to the external server, returning the decoded JSON response.
        '''
        if data is None:
            data = dict()

        server = self.__parameters().get('server').value
        url = urljoin(server, name)

        response = await pyfetch(url, method='POST', body=json.dumps(data), headers=JSON_HEADERS)
        contents = await response.json()

        return contents

    def schedule(self, duration, once, handler):
        r'''Schedule a call of the given handler after the given period.
        '''
        def callback():
            response = handler()
            if response is not None:
                self.write(response)

        return Scheduler(duration, once, callback)

    def write(self, line):
        r'''Write a text message to the output channel.
        '''
        chatbot_output = document.getElementById('chatbot-output')
        chatbot_output.innerHTML += line  + '<br><br>'
        chatbot_output.scrollTop = chatbot_output.scrollHeight


class Chatbot(commons.Chatbot):
    r'''CHADL chatbot backend for use in client-side browser applications.
    '''
    def __init__(self, model=None, context_factory=None):
        r'''Create a new chatbot backend.
        '''
        super().__init__(Dispatcher, model, context_factory)

    async def __call(self, state):
        r'''Perform an external call, given that this state contains one.
        '''
        call = state.call
        if call is None:
            return None

        parameters = self.context.parameters
        data = {parameter.name: parameters.get(parameter.name, parameter.value) for parameter in call.parameters.values()}
        response = await self.dispatcher.request(call.name, data)

        intent = response.pop('intent', None)

        for (name, value) in response.items():
            parameters[name] = value

        return intent

    async def __transition(self, state, fall_through=None):
        r'''Set the current state to the chatbot.
        '''
        if state is None:
            if fall_through is None:
                raise ChattingError('no intent found in state "%s" for utterance "%s"' % (self.context.current.name, utterance))
            else:
                yield fall_through.utterance
                return

        self.timeout.cancel()

        responses = list()
        while state is not None:
            response = self.context.set_current(state)
            if response is not None:
                yield response

            intent = await self.__call(state)
            state = self.context.get(intent)

        event = self.context.get_timeout()
        if event is not None:
            duration = float(event.parameters['duration'].value)
            once = (event.parameters.get('once') == 'true')
            self.timeout = self.dispatcher.schedule(duration, once, lambda: event % self.context.parameters)

    def start(self):
        r'''Start the deployed chatbot.
        '''
        self.dispatcher.start()
        state = self.context.get_start()
        return self.__transition(state)

    def exchange(self, utterance):
        r'''Play out an exchange with the chatbot.
        '''
        (state, fall_through) = self.context.find(utterance)
        return self.__transition(state, fall_through)
