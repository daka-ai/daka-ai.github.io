#!/usr/bin/env python
# -*- coding: utf-8 -*-

r'''Object model for CHADL agents.

    Author: Helio Perroni Filho
'''


import re
from collections import defaultdict


class ChattingError(Exception):
    r'''Exception class for chatbot runtime errors.
    '''
    def __init__(self, *args, **kwargs):
        r'''Create a new chatbot error object.
        '''
        super().__init__(*args, **kwargs)


class Agent:
    r'''A CHADL agent.
    '''
    def __init__(self):
        r'''Create a new agent.
        '''
        self.parameters = dict()
        self.intents = dict()
        self.states = States(self)
        self.events = dict()
        self.utterances = Utterances()

    def addIntent(self, name):
        r'''Add a new intent to the agent.

            Return the newly created intent.
        '''
        intent = self.intents.get(name)
        if intent is None:
            intent = Intent(self, name)
            self.intents[name] = intent

        return intent

    def addState(self, name):
        r'''Add a new state to the agent.

            Return the newly created state.
        '''
        states = self.states

        state = State(self, name)
        states[name] = state

        if states.start is None:
            states.start = state

        return state

    def addEvent(self, name, type, default):
        r'''Add a new event to the event.

            Return the newly created event.
        '''
        event = Event(self, name, type, default)

        self.events[name] = event
        if default:
            self.events[(type,)] = event

        return event

    def addTransition(self, state_from, intent, state_to):
        r'''Add a transition between states, mediated by an intent.
        '''
        self.states[state_from].addTransition(intent, state_to)

    def addUtterance(self, name, utterance):
        r'''Add a new utterance to the given intent, creating it if not yet available.
        '''
        self.addIntent(name)
        self.utterances.intents[name].append(utterance)


class States(dict):
    r'''Collection of agent states.
    '''
    def __init__(self, agent):
        r'''Create a new agent collection.
        '''
        super().__init__()
        self.__agent = agent
        self.__start = None

    @property
    def start(self):
        r'''Return the agent's start state.
        '''
        return self.__agent.states[self.__start]

    @start.setter
    def start(self, start):
        r'''Set the start state, either as a string or `State` object.
        '''
        if isinstance(start, str):
            self.__start = start
        else:
            self.__start = start.name


class Utterances:
    r'''Top-level utterance container.
    '''
    def __init__(self):
        r'''Create a new utterances container.
        '''
        self.intents = defaultdict(list)
        self.states = dict()
        self.events = dict()


class Uttering:
    r'''Super class of elements containing an (optional) output utterance.
    '''
    def __init__(self, name, utterances):
        r'''Create a new uttering element.
        '''
        self.__utterances = utterances
        self.name = name

    def __mod__(self, parameters):
        r'''Return the utterance with any parameters filled.
        '''
        utterance = self.utterance
        if utterance is None:
            return None

        def parameter(match):
            return parameters.get(match.group(1), match.group())

        return re.sub(r'\$([\w\-_]+)', parameter, utterance)

    @property
    def utterance(self):
        r'''Return the utterance associated with this element, if any.
        '''
        return self.__utterances.get(self.name)


class Intent:
    r'''Agent intent.
    '''
    def __init__(self, agent, name):
        r'''Create a new agent intent.
        '''
        self.__utterances = agent.utterances.intents
        self.name = name

    @property
    def utterances(self):
        r'''Return the utterances associated with this intent.
        '''
        return self.__utterances[self.name]


class State(Uttering):
    r'''Agent state.
    '''
    def __init__(self, agent, name, call=None):
        r'''Create a new agent state.
        '''
        super().__init__(name, agent.utterances.states)
        self.call = call
        self.transitions = Transitions()
        self.events = set()

    def addTransition(self, intent, condition, state):
        r'''Add a transition to this state.
        '''
        self.transitions.append(Transition(intent, condition, state))


class Call:
    r'''A call to an external system.
    '''
    def __init__(self, name):
        r'''Create a call to the given URI.
        '''
        self.name = name
        self.parameters = dict()


class Parameter:
    r'''A parameter in an intent or state.
    '''
    def __init__(self, name, value=None, persistent=False):
        r'''Create a new parameter.
        '''
        self.name = name
        self.value = value
        self.persistent = persistent


class Transitions(list):
    r'''Collection of state transitions.

        Maintains sub-collections of transitions by intent and condition.
    '''
    def __init__(self):
        r'''Create a new collection of transitions.
        '''
        super().__init__()
        self.intended = dict()
        self.conditioned = list()

    def __mod__(self, parameters):
        r'''Evaluate the conditional transitions in this collection, returning the
            state associated to the first transition that evaluates to true.

            If no conditional evaluates to true, return `None`.
        '''
        def parameter(match):
            value = parameters.get(match.group(1))
            return f"'{value}'" if value else 'None'

        for transition in self.conditioned:
            expression = re.sub(r'\$([\w\-_]+)', parameter, transition.condition)
            if eval(expression):
                return transition.state

        return None

    def append(self, transition):
        r'''Add a new transition to this collection.
        '''
        super().append(transition)

        if transition.condition is None:
            self.intended[transition.intent] = transition
        else:
            self.conditioned.append(transition)

    def get(self, intent):
        r'''Return a transition by intent.
        '''
        return self.intended.get(intent)

class Transition:
    r'''A transition between agent states.
    '''
    def __init__(self, intent, condition, state):
        r'''defines a transition to the given state, triggered by the given intent.
        '''
        self.intent = intent
        self.condition = condition
        self.state = state


class Event(Uttering):
    r'''An agent event.
    '''
    def __init__(self, agent, name, type, default):
        r'''Create a new event.
        '''
        super().__init__(name, agent.utterances.events)
        self.type = type
        self.default = default
        self.parameters = dict()
