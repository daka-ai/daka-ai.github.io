#!/usr/bin/env python
# -*- coding: utf-8 -*-

r'''Core logic routines for CHADL chatbots.

    Author: Helio Perroni Filho
'''


import os.path
from threading import Timer

import yaml

from chadl.commons.trie import TrieStateMachine
from chadl.commons.model import Agent, ChattingError


class Scheduler:
    r'''Object used to schedule a call for later execution.
    '''
    def __init__(self, duration, once, handler):
        r'''Create a new scheduler to call a handler after a duration, possibly
            repeatedly.
        '''
        self.once = once
        self.duration = duration
        self.handler = handler

        self.__schedule()

    def __schedule(self):
        r'''Schedule the handler for later execution.
        '''
        self.__timer = Timer(self.duration, self.__callback)

    def __callback(self):
        r'''Call the scheduled handler.
        '''
        self.handler()
        if not self.once:
            self.__schedule()

    def cancel(self):
        r'''Cancel the given timer.
        '''
        self.__timer.cancel()


class SchedulerOff:
    r'''Mock scheduler.
    '''
    def cancel(self):
        r'''Mock scheduler cancel.
        '''
        pass


class Dispatcher:
    r'''Interface for communicating with the chatbot's environment.
    '''
    def __init__(self, chatbot):
        r'''Create a new external system interface.
        '''
        self.chatbot = chatbot
        self.storage = dict()

    def start(self):
        r'''Start the interface to the external system.
        '''
        path = self.chatbot.context.parameters.get('storage', './parameters.yaml')
        if not os.path.isfile(path):
            return

        with open(path) as yaml_file:
            self.storage = yaml.load(yaml_file, Loader=yaml.Loader)

    def stop(self):
        r'''Stop the interface to the external system.
        '''
        path = self.chatbot.context.parameters.get('storage', './parameters.yaml')
        with open(path, 'w') as yaml_file:
            yaml.dump(self.storage, yaml_file)

    def request(self, name, data=None):
        r'''Perform a global function call of the form `handle_<name>(data)` and return its
            result.
        '''
        handler = globals().get(f'handle_{name}')
        if handler is None:
            return {
                'intent': 'error',
                'message': f'no handler found for "{name}" request'
            }

        return handler(data)

    def schedule(self, duration, once, handler):
        r'''Schedule a call of the given handler after the given period.
        '''
        def callback():
            response = handler()
            if response is not None:
                self.write(response)

        return Scheduler(duration, once, callback)

    def write(self, line):
        r'''Write a text message to the output channel.
        '''
        print(line)


class Chatbot:
    r'''A CHADL chatbot.
    '''
    def __init__(self, dispatcher_factory=None, model=None, context_factory=None):
        r'''Create a new chatbot backend.
        '''
        self.__model = (model or Agent())
        self.dispatcher = (dispatcher_factory or Dispatcher)(self)
        self.context = (context_factory or TrieStateMachine)(self)

        self.timeout = SchedulerOff()

    def __call(self, state):
        r'''Perform an external call, given that this state contains one.
        '''
        call = state.call
        if call is None:
            return None

        parameters = self.context.parameters
        data = {parameter.name: parameters.get(parameter.name, parameter.value) for parameter in call.parameters.values()}
        response = self.dispatcher.request(call.name, data)

        intent = response.pop('intent', None)

        for (name, value) in response.items():
            parameters[name] = value

        return intent

    def __transition(self, state):
        r'''Set the current state to the chatbot.
        '''
        self.timeout.cancel()

        responses = list()
        while state is not None:
            response = self.context.set_current(state)
            if response is not None:
                yield response

            intent = self.__call(state)
            state = self.context.get(intent)

        event = self.context.get_timeout()
        if event is not None:
            duration = float(event.parameters['duration'].value)
            once = (event.parameters.get('once') == 'true')
            self.timeout = self.dispatcher.schedule(duration, once, lambda: event % self.context.parameters)

    def update(self):
        r'''Reset the chatbot's context, synchronizing it to the current model.

            Also stops the chatbot.
        '''
        if self.started:
            self.context.update()

    def start(self):
        r'''Start the chatbot.
        '''
        self.dispatcher.start()
        state = self.context.get_start()
        return self.__transition(state)

    def stop(self):
        r'''Stop the chatbot.
        '''
        self.dispatcher.stop()
        self.context.reset()

    def exchange(self, utterance):
        r'''Play out an exchange with the chatbot.
        '''
        (state, fall_through) = self.context.find(utterance)
        if state is not None:
            return self.__transition(state)

        if fall_through is not None:
            return [fall_through.utterance]

        raise ChattingError('no intent found in state "%s" for utterance "%s"' % (self.context.current.name, utterance))

    def handle(self, message):
        r'''Process a message containing triggered events.
        '''
        parameters = self.context.parameters

        for entry in message:
            event_type = entry.pop('type')

            event = self.context.get_event(event_type)
            if event is None:
                continue

            for (name, value) in entry.items():
                parameters[name] = value

            yield event % parameters

    @property
    def model(self):
        r'''Return the chatbot's agent model.
        '''
        return self.__model

    @model.setter
    def model(self, model):
        r'''Update the chatbot's agent model.
        '''
        self.__model = model
        self.update()

    @property
    def started(self):
        r'''Returns whether the chatbot is running.
        '''
        return (self.context.current is not None)
