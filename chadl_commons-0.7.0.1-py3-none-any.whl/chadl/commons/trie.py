#!/usr/bin/env python
# -*- coding: utf-8 -*-

r'''Chatbot state machine built around an implementation of the Trie data structure.

    Author: Helio Perroni Filho
'''


import re
from collections import defaultdict

from chadl.commons.model import ChattingError


def tokenize(state, utterance):
    r'''Convert a utterance into a sequence of tokens and parameters.
    '''
    elements = [Token(state, 0, len(state))]
    for match in re.finditer('\$?[\w\-_]+', utterance):
        value = match.group()
        if value.startswith('$'):
            elements.append(Parameter(value[1:]))
        else:
            elements.append(Token(value, match.start(), match.end()))

    return elements


class Token(str):
    r'''A token (normalized word) in an utterance.
    '''
    def __new__(cls, value, start, end):
        r'''Create a new token.
        '''
        o = str.__new__(cls, value.lower())
        o.start = start
        o.end = end
        return o


class Parameter(str):
    r'''A named parameter.
    '''
    def __new__(cls, name):
        r'''Create a new named parameter.
        '''
        return str.__new__(cls, name)


class Node(object):
    r'''A node in a Trie.

        Every node contains three (possibly empty) children dictionaries. One
        contains nodes indexed by common (non-wildcard) keys; the other two
        store wildcard-indexed nodes. The two wildcard dictionaries separate
        wildcards with negative priority (which are matched against query key
        sequences before non-wildcard entries) from those with positive priority
        (which are matched last). Nodes can also store values. Leaf nodes will
        always hold a stored value, while non-leaf nodes may not.
    '''
    def __init__(self):
        r'''Creates a new Node object.
        '''
        self.children = defaultdict(Node)
        self.parameters = defaultdict(Node)
        self.value = None

    def update(self, keys, value):
        r'''Adds the given key / value pair to the subtree topped by this node,
            possibly creating new subnodes along the way.
        '''
        if keys:
            (key, keys) = (keys[0], keys[1:])
            self.child(key).update(keys, value)
        else:
            self.value = value

    def child(self, key):
        r'''Returns the child node associated to the given key, creating it if not found.

            If the key is a parameter, the node is sought / created in the parameter
            dictionary.
        '''
        if isinstance(key, Parameter):
            return self.parameters[key]

        return self.children[key]

    def get(self, keys):
        r'''Returns a list of values matched by the given key.

            If no matches are found, returns an empty list.
        '''
        if not keys:
            return (self.value, dict())

        child = self.children.get(keys[0])
        if child is not None:
            return child.get(keys[1:])

        for (parameter, child) in self.parameters.items():
            for l in range(1, len(keys) + 1):
                (value, matches) = child.get(keys[l:])
                if value is not None:
                    matches[parameter] = keys[:l]
                    return (value, matches)

        return (None, dict())


class Parameters:
    r'''Dictionary of chatbot parameter values.

        Includes logic for preserving and restoring persistent parameters.
    '''
    def __init__(self, chatbot):
        r'''Create a new dictionary to manage chatbot parameter values.
        '''
        self.__parameters = dict()
        self.chatbot = chatbot

    def __getitem__(self, name):
        r'''Return a parameter value, or a default value if not found.
        '''
        parameter = self.chatbot.model.parameters.get(name)
        if parameter is None:
            return self.__parameters[name]

        parameters = self.chatbot.dispatcher.storage if parameter.persistent else self.__parameters

        return parameters.get(name, parameter.value)

    def __setitem__(self, name, value):
        r'''Update a parameter value.
        '''
        parameter = self.chatbot.model.parameters.get(name)
        if parameter is None:
            self.__parameters[name] = value
            return

        parameters = self.chatbot.dispatcher.storage if parameter.persistent else self.__parameters

        parameters[name] = value

    def get(self, name, default=None):
        r'''Return a parameter value, or a default value if not found.
        '''
        parameter = self.chatbot.model.parameters.get(name)
        if parameter is None:
            return self.__parameters.get(name, default)

        parameters = self.chatbot.dispatcher.storage if parameter.persistent else self.__parameters

        value = parameters.get(name, parameter.value)
        if value is None:
            return default

        return value


class TrieStateMachine(object):
    r'''A Trie-based ChaDL chatbot state machine.
    '''
    def __init__(self, chatbot):
        r'''Create a new chatbot backend.
        '''
        self.chatbot = chatbot
        self.parameters = Parameters(chatbot)
        self.current = None
        self.root = None

    def reset(self):
        r'''Reset the state machine.
        '''
        self.current = None

    def find(self, utterance):
        r'''Match the given utterance to a state, updating internal parameters in the process.

            If the utterance cannot be matched, raise `ChattingError`.
        '''
        (intent, parameters) = self.root.get(tokenize(self.current.name, utterance))
        if intent is None:
            return (None, self.get_fall_through())

        transition = self.current.transitions.get(intent)
        if transition is None:
            raise ChattingError('no transition found for intent "%s" in current state "%s"' % (intent, self.current.name))

        state = self.chatbot.model.states.get(transition.state)
        if state is None:
            raise ChattingError('state "%s" not found' % transition.state)

        for (name, tokens) in parameters.items():
            a = tokens[0].start
            b = tokens[-1].end
            self.parameters[name] = utterance[a:b]

        return (state, None)

    def get(self, intent):
        r'''Return the next state for the given (possibly `None`) intent.
        '''
        if intent is None:
            state = self.current.transitions % self.parameters
            if state is not None:
                return self.chatbot.model.states.get(state)

        transition = self.current.transitions.get(intent)

        if transition is not None:
            return self.chatbot.model.states.get(transition.state)

        if intent is not None:
            raise ChattingError(f'Intent "{intent}" not found')

        return None

    def get_event(self, type):
        r'''Return an event of the given type for the current state.
        '''
        events = self.chatbot.model.events
        for name in self.current.events:
            event = events.get(name)
            if event is not None and event.type == type:
                return event

        event = events.get((type,))
        if event is not None:
            return event

        return None

    def get_fall_through(self):
        r'''Return the fall through response for the current state.
        '''
        return self.get_event('fall-through')

    def get_timeout(self):
        r'''Return timeout duration for the current state.
        '''
        return self.get_event('timeout')

    def get_start(self):
        r'''Return the state machine's start state.
        '''
        if self.root is None:
            self.update()

        return self.chatbot.model.states.start

    def set_current(self, state):
        r'''Set the current state, returning its utterance.
        '''
        if state is None:
            raise ChattingError('state is not defined')

        self.current = state
        return state % self.parameters

    def update(self):
        r'''(Re)write chatbot states to this state machine.
        '''
        self.root = Node()

        intents = self.chatbot.model.intents
        for state in self.chatbot.model.states.values():
            for transition in state.transitions.intended.values():
                intent = intents.get(transition.intent)
                if intent is None:
                    continue

                for utterance in intent.utterances:
                    keys = tokenize(state.name, utterance)
                    self.root.update(keys, intent.name)

        # If this state machine is not running, end the update here.
        if self.current is None:
            return

        # If the previous current state does not exist anymore, stop the state machine.
        name = self.current.name
        state = self.chatbot.model.states.get(name)
        if state is None:
            self.parameters.clear()
            self.current = None
            raise ChattingError('current state removed')

        # Otherwise, reinstate the current state.
        self.current = state
