#!/usr/bin/env python
# -*- coding: utf-8 -*-

r'''CHADL language parsing routines.

    Author: Helio Perroni Filho
'''


import os
import xml.etree.ElementTree as xet
import xml.sax as sax
from itertools import chain

from chadl.commons.model import *


# Convenience singleton object for creating XML elements with no attributes.
NO_ATTRS = dict()


def indent(elem, level=0):
    r'''Add indentation to an element tree prior to saving.

        See: https://stackoverflow.com/a/33956544/476920
    '''
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i


def save(agent, path_agent):
    r'''Save an agent's logic and utterances to separate files.
    '''
    path_utterances = os.path.splitext(path_agent)[0] + '_utterances.xml'
    saveAgent(agent, path_agent, path_utterances)
    saveUtterances(agent, path_utterances)


def addIfNotNone(attributes, name, value):
    r'''Update the given attribute dictionary if the value is not `None`.
    '''
    if value is not None:
        attributes[name] = value


def saveAgent(agent, path_agent, path_utterances):
    r'''Save an agent's logic to file.
    '''
    builder = xet.TreeBuilder()

    builder.start('agent', {'xmlns': 'http://daka-ai.com/chadl/2022-01/agent.xsd'})

    path_utterances = os.path.relpath(path_utterances, os.path.dirname(path_agent))
    builder.start('include', {'href': path_utterances})
    builder.end('include')

    builder.start('parameters', NO_ATTRS)

    for (name, parameter) in agent.parameters.items():
        attributes = {
            'name': name,
            'value': parameter.value,
            'persistent': parameter.persistent
        }

        builder.start('parameter', attributes)
        builder.end('parameter')

    builder.end('parameters')

    builder.start('intents', NO_ATTRS)

    for name in agent.intents.keys():
        builder.start('intent', {'name': name})
        builder.end('intent')

    builder.end('intents')

    builder.start('states', {'start': agent.states.start.name})

    for (name, state) in agent.states.items():
        builder.start('state', {'name': name})

        for transition in state.transitions:
            attributes = dict()
            addIfNotNone(attributes, 'intent', transition.intent)
            addIfNotNone(attributes, 'if', transition.condition)
            attributes['state'] = transition.state

            builder.start('transition', attributes)
            builder.end('transition')

        builder.end('state')

    builder.end('states')

    builder.end('agent')

    root = builder.close()
    indent(root)

    tree = xet.ElementTree(root)
    tree.write(path_agent, encoding='unicode', xml_declaration=True)


def saveUtterances(agent, path):
    r'''Save agent utterances to an XML file.
    '''
    builder = xet.TreeBuilder()

    builder.start('utterances', {'xmlns': 'http://daka-ai.com/chadl/2022-01/utterances.xsd'})

    builder.start('intents', NO_ATTRS)

    for (name, intent) in agent.intents.items():
        builder.start('intent', {'name': name})

        for utterance in intent.utterances:
            builder.start('li', NO_ATTRS)
            builder.data(utterance)
            builder.end('li')

        builder.end('intent')

    builder.end('intents')

    builder.start('states', NO_ATTRS)

    for (name, state) in agent.states.items():
        builder.start('state', {'name': name})
        builder.data(state.utterance)
        builder.end('state')

    builder.end('states')

    builder.end('utterances')

    root = builder.close()
    indent(root)

    tree = xet.ElementTree(root)
    tree.write(path, encoding='unicode', xml_declaration=True)


class ReflectionHandler(sax.ContentHandler):
    r'''Content handler that redirects start and end tags to handler methods.
    '''
    def handleElement(self, handler_name, *args):
        r'''Redirect a start or end tag to a handler.
        '''
        if not hasattr(self, handler_name):
            return

        handler = getattr(self, handler_name)
        handler(*args)

    def startElement(self, name, attributes):
        r'''Event handler called when the parser finds a start tag.
        '''
        self.handleElement('start_' + name, attributes)

    def endElement(self, name):
        r'''Event handler called when the parser finds an end tag.
        '''
        self.handleElement('end_' + name)


class AgentHandler(ReflectionHandler):
    r'''Parsing handler for agent XML files.
    '''
    def __init__(self, agent):
        r'''Create a new handler object.
        '''
        self.agent = agent
        self.current_state = None
        self.current_parameterized = None

    def start_intent(self, attributes):
        r'''Handle a start `<intent>` tag.
        '''
        self.agent.addIntent(attributes['name'])

    def start_parameters(self, attributes):
        r'''Handle a start `<parameters>` tag.
        '''
        self.current_parameterized = self.agent

    def end_parameters(self):
        r'''Handle an end `</parameters>` tag.
        '''
        self.current_parameterized = None

    def start_states(self, attributes):
        r'''Handle a start `<states>` tag.
        '''
        self.agent.states.start = attributes['start']

    def start_state(self, attributes):
        r'''Handle a start `<state>` tag.
        '''
        self.current_state = self.agent.addState(attributes['name'])

    def end_state(self):
        r'''Handle an end `</state>` tag.
        '''
        self.current_state = None
        self.current_parameterized = None

    def start_call(self, attributes):
        r'''Handle a start `<call>` tag.
        '''
        name = attributes['name']
        call = Call(name)

        self.current_state.call = call
        self.current_parameterized = call

    def start_parameter(self, attributes):
        r'''Handle a start `<parameter>` tag.
        '''
        name = attributes['name']
        value = attributes.get('value')
        persistent = attributes.get('persistent', False)
        self.current_parameterized.parameters[name] = Parameter(name, value, persistent)

    def start_transition(self, attributes):
        r'''Handle a start `<transition>` tag.
        '''
        intent = attributes.get('intent')
        condition = attributes.get('if')
        state = attributes['state']

        self.current_state.addTransition(intent, condition, state)

    def start_event(self, attributes):
        r'''Handle a start `<event>` tag.
        '''
        name = attributes['name']
        if self.current_state is not None:
            self.current_state.events.add(name)
            return

        type = attributes['type']
        default = attributes.get('default', False)

        self.current_parameterized = self.agent.addEvent(name, type, default)

    def end_event(self):
        r'''Handle an end `</event>` tag.
        '''
        self.current_parameterized = None


class UtterancesHandler(ReflectionHandler):
    r'''Parsing handler for utterances XML files.
    '''
    def __init__(self, agent):
        r'''Create a new handler object.
        '''
        self.agent = agent
        self.name = None
        self.utterances = None
        self.utterance = ''

    def __start_element(self, attributes, utterances):
        r'''Handle a start tag.
        '''
        self.name = attributes['name']
        self.utterances = utterances
        self.utterance = ''

    def __end_element(self):
        r'''Handle an end tag.
        '''
        self.utterances[self.name] = self.utterance.strip()

    def characters(self, content):
        r'''Handle a block of character data.
        '''
        self.utterance += content

    def start_intent(self, attributes):
        r'''Handle a start `<intent>` tag.
        '''
        self.__start_element(attributes, self.agent.utterances.intents)

    def start_li(self, attributes):
        r'''Handle a start `<li>` tag.
        '''
        self.utterance = ''

    def end_li(self):
        r'''Handle an end `</li>` tag.
        '''
        self.utterances[self.name].append(self.utterance.strip())

    def start_state(self, attributes):
        r'''Handle a start `<state>` tag.
        '''
        self.__start_element(attributes, self.agent.utterances.states)

    def end_state(self):
        r'''Handle an end `</state>` tag.
        '''
        self.__end_element()

    def start_event(self, attributes):
        r'''Handle a start `<event>` tag.
        '''
        self.__start_element(attributes, self.agent.utterances.events)

    def end_event(self):
        r'''Handle an end `</event>` tag.
        '''
        self.__end_element()


class ParserHandler(sax.ContentHandler):
    r'''Parsing handler for ChaDL XML files.

        This handler encapsulates an `AgentHandler` and a `UtterancesHandler`,
        dispatching events to each as appropriate.
    '''
    def __init__(self, agent):
        r'''Create a new handler object.
        '''
        self.includes = list()

        self.handler = None

        self.handlers = {
            'agent': AgentHandler(agent),
            'utterances': UtterancesHandler(agent)
        }

    def setDocumentLocator(self, locator):
        r'''Set the document locator that can help locate parsing errors in the originating
            XML file.
        '''
        sax.ContentHandler.setDocumentLocator(self, locator)
        for handler in self.handlers.values():
            handler.setDocumentLocator(locator)

    def characters(self, content):
        r'''Event handler called when the parser finds a block of characters inside a tag.
        '''
        if self.handler is None:
            raise sax.SAXParseException('delegating handler not set', None, self._locator)

        try:
            self.handler.characters(content)
        except Exception as e:
            raise sax.SAXParseException(str(e), e, self._locator)

    def startElement(self, name, attributes):
        r'''Event handler called when the parser finds a start tag.
        '''
        if name == 'include':
            self.includes.append(attributes['href'])
            return

        if self.handler is not None:
            try:
                self.handler.startElement(name, attributes)
            except Exception as e:
                raise sax.SAXParseException(str(e), e, self._locator)

            return

        handler = self.handlers.get(name)
        if handler is None:
            raise sax.SAXParseException('illegal top element <%s>' % name, None, self._locator)

        self.handler = handler

    def endElement(self, name):
        r'''Event handler called when the parser finds an end tag.
        '''
        if self.handler is None:
            raise sax.SAXParseException('delegating handler not set', None, self._locator)

        try:
            self.handler.endElement(name)
        except Exception as e:
            raise sax.SAXParseException(str(e), e, self._locator)


class FileLoader:
    r'''Class for loading agent documents from the local file system.
    '''
    def __init__(self, path):
        r'''Create a new loader for the agent in the given path.
        '''
        (self.folder, self.agent) = os.path.split(path)

    def __call__(self, name=None):
        r'''Load a document by the given name.
        '''
        if name is None:
            name = self.agent

        return open(os.path.join(self.folder, name))


def parse(path, loader=FileLoader):
    r'''Parse an agent from an XML file.
    '''
    agent = Agent()

    load = loader(path)

    def parse_include(name):
        parser = sax.make_parser()

        handler = ParserHandler(agent)
        parser.setContentHandler(handler)
        parser.parse(load(name))

        return handler.includes

    includes = [None]
    while includes:
        includes = list(chain(*(parse_include(include) for include in includes)))

    return agent
